<?php
$con = new mysqli("localhost", "root", "Kar$", "agrifarm");
if($con->connect_error){
	die("connection failed".$con->connect_error);
}
?>