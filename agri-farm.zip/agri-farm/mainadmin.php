<!DOCTYPE html>
<html>
<head>
	<title>AgriFarm Admin</title>
	<style type="text/css">
		li {
			width:100%;
			height:40px;
			text-align: center;
			vertical-align: middle;
			color: white;
			padding-top: 15px;
		}
		li:hover{
			background-color: white;
			 color: black;
			 cursor: pointer;
		}
		li:active{
			background-color: white;
			 color: black;
		}
		ul{
			list-style: none;
		}
		input[type='text']{
			height: 30px;
			padding: 0px 5px 0px 5px;
			margin-right: 5px;

		}
		form input[type='submit']{
			height: 30px;
			min-width: 60px;
		}
	</style>
</head>
<body>
	<div style="height: 700px; width:20%; background-image: url('bg.gif'); float: left;">
		<ul style="padding-left: 0px;">
			
				
			<br><br>
			<li onclick="d1(); ">Add iFrame</li>
			<li onclick="d2();" >Update price</li>
			<li onclick="d3();">Suggestions</li>
			<li onclick="d4();">Technology</li>
		</ul>
	</div>
	<div style="width:80%; background-image: url('af.jpg'); height: 700px; float: right;">
		<br><center><img src="logo.png" style="height: 92px; width: 350px;"></center><br><br><center>
		<form id="d1" action="admin.php" method="post">
			<input type="text" name="typ" value="1" style="display: none;">
			<input type="text" name="ifname" placeholder="Enter youtube iFrame" required="required" autofocus="autofocus" >
			<input type="submit" value="Add">
		</form>
		<form id="d2" action="admin.php" method="post" style="display: none;">
			<input type="text" name="typ" value="2" style="display:none;">
			<input type="text" name="cname" placeholder="Enter crop name" required="required" autofocus="autofocus">
			<input type="text" name="cprice" placeholder="Enter crop price" required="required">
			<input type="text" name="ccity" placeholder="Enter city" required="required">
			<input type="submit" value="Add">
		</form>
		</center>
		<form id="d4" action="admin.php" method="post" style="display: none;">
			<input type="text" name="typ" value="3" style="display: none;">
			<input type="text" name="nam" placeholder="Enter the header" style="width: 100%;"><br>
			<textarea name="content" placeholder="Enter description" style="width: 100%; height: 300px;"></textarea><br>
			<input type="text" name="imgl" placeholder="Enter Image link" style="width: 100%;"><br><input type="submit" value="Add">
		</form>
		<div id="d3" style="display: none;">
			<?php
				include('auth.php');
				$q = 'select name, email, sug, dat from report where dat in (select dat from report group by dat order by dat desc) order by dat desc;' ;
				if($r = $con->query($q)){
					while($row = $r->fetch_assoc()){
						echo "<div style=\"background-color:rgba(225,225,225,.9); padding-left:40px;\"><br>";
						echo "<h4>$row[name]</h4>$row[sug]<br><br><b><em>$row[email]</em></b><br><em>$row[dat]</em>";
						echo "<br></div><br>";
					}
				}
			?>
		</div>
	</div>
</body>
<script type="text/javascript">
	function d1(){
		var f = document.getElementById('d1');
		f.style.display='block';
		f = document.getElementById('d2');
		f.style.display='none';
		f = document.getElementById('d3');
		f.style.display='none';
		f = document.getElementById('d4');
		f.style.display='none';
	}
	function d2(){
		var f = document.getElementById('d2');
		f.style.display='block';
		f = document.getElementById('d1');
		f.style.display='none';
		f = document.getElementById('d3');
		f.style.display='none';
		f = document.getElementById('d4');
		f.style.display='none';
	}
	function d3(){
		var f = document.getElementById('d2');
		f.style.display='none';
		f = document.getElementById('d1');
		f.style.display='none';
		f = document.getElementById('d3');
		f.style.display='block';
		f = document.getElementById('d4');
		f.style.display='none';
	}
	function d4(){
		var f = document.getElementById('d2');
		f.style.display='none';
		f = document.getElementById('d1');
		f.style.display='none';
		f = document.getElementById('d3');
		f.style.display='none';
		f = document.getElementById('d4');
		f.style.display='block';
	}
</script>
</html>