

<?php
$f1 = $_POST['typ'];
if($f1 == '1'){
	$f = $_POST['ifname'];
	$q= "INSERT INTO vids(link) VALUES('".$f."');";

	include('auth.php');
	if($con->query($q))
	{
		echo "<script>alert('Success');location.href='mainadmin.php';</script>";
	}
	else{
		echo "<script>alert('Insert failed');location.href='mainadmin.php';</script>";
	}
}
elseif($f1 == '2'){
	$f1 = $_POST['cname'];
	$f2 = $_POST['cprice'];
	$f3 = $_POST['ccity'];

	$q = "SELECT city FROM crop WHERE name = \"$f1\" and city =\"$f3\";" ;
	include('auth.php');
	$r = $con->query($q);
	if($r->num_rows>0)
	{
		//$q = "ALTER TABLE crop set price=\"$f2\" where name = \"$f1\" and city =\"$f3\";"  ;
		$q = "update crop set price=\"$f2\" where name = \"$f1\" and city =\"$f3\";"  ;
		if($con->query($q))
		echo "<script>alert('Price updated');location.href='mainadmin.php';</script>";
		else 	echo "<script>alert('Price update failed');location.href='mainadmin.php';</script>";
	}
	else{
 $q = "INSERT INTO crop VALUES(\"$f1\", \"$f3\", \"$f2\");";
 if($con->query($q))
		echo "<script>alert('Insert Sucess');location.href='mainadmin.php';</script>";
		else echo "<script>alert('Insert failed');location.href='mainadmin.php';</script>";
	}
}
elseif ($f1 == '3') {
	$f1 = $_POST['nam'];
	$f2 = $_POST['content'];
	$f3 = $_POST['imgl'];

	$q = "insert into tech(name, content, imgl) values(\"$f1\", \"$f2\",\"$f3\");";
include('auth.php');
	if($con->query($q))
		echo "<script>alert('Insert Sucess');location.href='mainadmin.php';</script>";
		else echo "<script>alert('Insert failed');location.href='mainadmin.php';</script>";
	
	# code...
}

?>
