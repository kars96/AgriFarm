<?php
$n = $_POST['nam'];
$e = $_POST['mail'];
$s = $_POST['suggest'];

include('auth.php');

$q = "INSERT INTO report(name, email, sug) VALUES('$n', '$e', '$s');";

if($con->query($q) == TRUE){
	echo "<script>alert('Thanks for suggestion');location.href='frontpage.php';</script>";
}
?>