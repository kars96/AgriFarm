<html>
   <head>
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <title>AGRIFARM</title>
      <script
  src="https://code.jquery.com/jquery-2.2.4.js"
  integrity="sha256-iT6Q9iMJYuQiMWNd9lDyBUStIq/8PuOW33aOqmvFpqI="
  crossorigin="anonymous"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.3/umd/popper.min.js" integrity="sha384-vFJXuSJphROIrBnz7yo7oB41mKfc8JzQZiCq4NCceLEaO4IHwicKwpJf9c9IpFgh" crossorigin="anonymous"></script>
      <!-- Latest compiled and minified CSS -->
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">
      <!-- Optional theme -->
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap-theme.min.css" integrity="sha384-fLW2N01lMqjakBkx3l/M9EahuwpSfeNvV63J5ezn3uZzapT0u7EYsXMjQV+0En5r" crossorigin="anonymous">
      <!-- Latest compiled and minified JavaScript -->
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js" integrity="sha384-0mSbJDEHialfmuBBQP6A4Qrprq5OVfW37PRR3j5ELqxss1yVqOtnepnHVP9aJ7xS" crossorigin="anonymous"></script>
      <script type="text/javascript" src="frontpage.js"></script>
      <link rel="stylesheet" type="text/css" href="frontpage.css">
      <style type="text/css">
        select {
          background-color: #337AB7;
          border:none;
          color: white;
          height: 30px;
          min-width: 80px;
          padding-right: 3px;
          padding-left: 3px;
        }
        select option {
          height: 20px;
          background-color: white;
          color: black;
        }
      </style>
   </head>
   <body>
      <center><img class="img img-responsive img-rounded " src="logo.png" style="height: 92px; width: 350px; position: relative; right: 5px;"></center>
      <div class="container">
         <ul class="nav nav-pills navbar-inverse" style="color:#54BDDC; font-weight: bold;" >
            <li class="active"><a data-toggle="pill" href="#about">Home</a></li>
            <li><a data-toggle="pill" href="#news">News</a></li>
            <li><a data-toggle="pill" href="#price">Pricing</a></li>
            <li class="dropdown">
         	<a href="#" data-toggle="dropdown" class="dropdown-toggle">Crop<span class="caret"></span></a>
         	<ul class="dropdown-menu">
         		<li><a href="#state" data-toggle="tab">Statewise</a></li>
         		<li><a href="#season" data-toggle="tab">Seasonwise</a></li>
         		<li><a href="#soil" data-toggle="tab">Soilwise</a></li>
         	</ul>
         	</li>
         	<li><a href="#tech" data-toggle="pill">Technology</a></li>
            <li><a data-toggle="pill" href="#fertilizer">Fertilizer</a></li>
            <li><a data-toggle="pill" href="#help">Helpline</a></li>
            <li><a data-toggle="pill" href="#contact">Contact us</a></li>
            
         </ul>
         
         <div class="tab-content">
            <div id="about" class="tab-pane fade in active">
               <div class="container">
                  <!-- content -->
               </div>
               <br>
               <div >
                <center>
                  <div style="display: inline-block; margin: 0 auto; text-align: right;">
                    <p><em>&quot;Teaching kids how to feed themselves and how to live in a community responsibly is the center of an education.&quot;</em><br>
&#45;Alice Waters</p>
                  </div>
                </center>
                <div class="container" style="font-size: 20px;"> 
<br>
                  Agri Farm is a site for farmers. It aims in bringing awareness about the traditional farming methods and modern farming methods and highlight the commonly made mistakes made by farmers.<br><br>
                 
                </div>
                  <center>
                     <span style="font-family: 'Courier New'; font-size: large; font-weight: bold;">So what level are you?</span><br>
                     <div class="btn-group " role="group" aria-label="...">
                        <div class="btn-group" role="group">
                           <button type="button" class="btn btn-info" id="begb">Beginner</button>
                        </div>
                        <!-- <div class="btn-group" role="group">
                           <button type="button" class="btn btn-info" id="intb">Intermediate</button>
                        </div> -->
                        <div class="btn-group" role="group">
                           <button type="button" class="btn btn-info" id="expb">Expert</button>
                        </div>
                        <br>
                     </div>
                  </center>
                  <!-- <div class="container"> -->
                  <div id="beg" style="background-image: url('bg.gif'); border-radius: 2px 2px 2px 2px; box-shadow: 0px 0px 5px #888888; display: none;">
                     <div style="color: white; font-size: medium; padding-left: 20px; padding-right: 20px;">
                        <br>
                        Are you&apos;re thinking about starting a farm? This guide is here to help you take initial steps.<br>
                        We provide an overview of the topic of starting a farm and point you in the direction of free information and resources to help you get started.<br>
                        This guide is primarily oriented toward small farm operations.<br>
                        It&apos;s Complicated!: Starting a farm is complicated because it encompasses so much. In no particular order, farmers must consider business planning, finding land, securing financing, marketing, production knowledge, securing equipment, developing or securing infrastructure, and their vision for their farm, a product of their values, knowledge and experience.<br>
                        <br>
                        <strong>What to Consider?</strong><br />
                        <ul style="color: white; font-size: medium;">
                           <li>
                              <strong>Vision and Values</strong>: A farm is both an extension of the vision and values of the individual(s) who start(s) it, and it has to be carefully planned to make sure that it fits within that vision as well as within the particular confines of the place where it is established.
                           </li>
                           <br />
                           <li>
                              <strong>Place Matters</strong>: Direct market farms typically aren&apos;t well suited for the rural heartland, and rice farming is not going to be successful on the arid plains of Eastern Washington. These are extreme examples, but there are important subtleties to every market and every plot of land.
                           </li>
                           <br />
                           <li>
                              <strong>Planning</strong>: New farms need to have a well designed business plan that takes into consideration individual infrastructure and financial needs, the viability of marketing strategies, and the farmer&apos;s production capacity and knowledge.
                           </li>
                           <br />
                           <li>
                              <strong>Education and Experience</strong>: Preparation, knowledge, and training are essential. But so is being able adapt quickly to the unexpected, to persevere when factors beyond one&apos;s control conspire against you, and knowing how/when/what/where to expend time, energy, and resources.
                           </li>
                           <br />
                           <li>
                              <strong>Managing risk</strong>: It is helpful to plan careful to manage risk through diversification, financial management, and the ability to withstand a couple of bad years.
                           </li>
                           <br />
                           <li>
                              <strong>Start small</strong>: For most beginning farmers, we advise starting small to allow time for details to be worked out, for additional learning to occur, and to mitigate the size and scope of problems that will inevitably arise.
                           </li>
                           <br />
                        </ul>
                     </div>
                  </div>
                  <div id="exp" style="background-image: url('bg.gif'); border-radius: 2px 2px 2px 2px; box-shadow: 0px 0px 5px #888888; display: none;">
                    <div style="color: white; font-size: medium; padding-left: 20px; padding-right: 20px;">
                        <br>
                        Are you an expert in farming, then try out these steps to increase the yeild.<br/><br>
                        <ul style="color: white; font-size: medium;">
                          <li>
                            <strong>Practice Composting</strong>: Compost is rich in nutrients. The compost itself is beneficial for the land in many ways, including as a soil conditioner, a fertilizer, addition of vital humus or humic acids, and as a natural pesticide for soil. Compost is useful for erosion control, land and stream reclamation, wetland construction, and as landfill cover 
                          </li>
                          <li>
                            <strong>Improving the distribution of agricultural products</strong>: Distribution systems are extremely unequal in most tropical countries, and often unreliable. Access to food and other agricultural goods must be increased in terms both of availability (delivery) and affordability.
                          </li>
                          <li><strong>Practice Seasonal Soil Rotation</strong>: Crop rotation is the practice of growing a series of dissimilar or different types of crops in the same area in sequenced seasons. It is done so that the soil of farms is not used for only one set of nutrients. It helps in reducing soil erosion and increases soil fertility and crop yield.</li>
                          <li>
                            <strong> Always Scout Your Fields</strong>: The most sage advice you can receive about how to increase crop yields is by scouting your fields on foot. This will give you a chance to assess soil conditions, notice any weeds cropping up, and check that your crops are growing healthily.
                          </li>
                          <li>
                            <strong>Ensure Proper Water Drainage </strong>: It&apos;s important to ensure your crop is getting enough water, but also that they aren&apos;t being over-watered. Developing a drainage system in your crops can help prevent waterlogging and salinization in your soil, both of which can stifle growth and production. 
                          </li>
                          <li>
                            <strong>Test Your Soil</strong>: Examining the phosphorus, potassium, and fertilization levels will give you insight into how to handle your crops. 
                          </li>
                        </ul>
                  </div>
                  <br>
                  </div>
               </div>
            </div>
            <div class="tab-pane fade in" id="contact">
            <br>
            <br>
                <div class="" style="background-image: url('bg.gif')">
                    <br>
                    <span style="font-size: 30px; color: white; padding-left: 50px;" > Need help? </span><br>
                    <form class="form-horizontal" style="padding-left: 25vw;" action="sugsub.php" method="post">
                        <div class="form-group">
                            <label for="nam" class="col-md-2" style="color: white;">Name</label>
                            <div class="col-md-5"><input type="text" name="nam" style="width: 400px;" required></div>
                        </div>
                        <div class="form-group">
                            <label for="mail" class="col-md-2" style="color: white;">E-mail</label>
                            <div class="col-md-5"><input type="email" name="mail" style="width: 400px;" required></div>
                        </div>
                        <div class="form-group">
                            <label for="suggest" class="col-md-2" style="color: white;">Suggestions</label>
                            <div class="col-md-5"><textarea name="suggest" rows='5' style="width: 400px;" required></textarea></div>
                        </div>
                       <input type="submit" name="" value="Submit" class="btn btn-info">
                        
                    </form>
                    <br>
                    
                </div>  
            </div>
            <div class="tab-pane" id="help"><br><br>
            <div id="exp" style="background-image: url('bg.gif'); border-radius: 2px 2px 2px 2px; box-shadow: 0px 0px 5px #888888;">
                    <div  style="color: white; font-size: medium; padding-left: 20px; padding-right: 20px;"><br>
<p>Kisan Call Center ::<strong style="color:#54BDDC">1800-180-1551</strong>  (from any Landline or Mobile) / <strong style="color:#54BDDC">1551</strong> (from BSNL Landline)</p>

<p>The Department of Agriculture & Cooperation (DAC), Ministry of Agriculture, Govt. of India launched Kisan Call Centers on January 21, 2004 across the country to deliver extension services to the farming community.</p>

<p>The purpose of these call centers is to respond to issues raised by farmers, instantly, in the local language. There are call centers for every state which are expected to handle traffic from any part of the country. Queries related to agriculture and allied sectors are being addressed through these call centers.</p>

<p>A farmer from any part of the State can contact the Kisan Call Centre by dialing the toll free Telephone No. <strong style="color:#54BDDC">1551</strong> or <strong style="color:#54BDDC">1800-180-1551</strong> and present their problems/queries related to farming. The operator at the Kisan Call centre will attempt to answer the problems/queries of the farmers immediately. In case the operator at the Call Centre is not able to address the farmer's query immediately, the call will be forwarded to identified agricultural specialists.</p><br>
</div>
            </div>
         </div>

          <div id="state" class="tab-pane">
            <br>
            <br>

            <table class="table table-bordered table-responsive table-stripped"  style="background-color: rgba(220, 220, 220, .85);"><tbody>
<tr bgcolor="#C0C0C0"><th>Crops</th><th>States</th></tr>
<tr><td><b>Bajra </b></td><td>Gujarat, Rajasthan</td></tr>
<tr><td><b>Barley </b></td><td>Uttar Pradesh, Rajasthan</td></tr>
<tr><td><b>Cardamom </b></td><td>Karnataka, Kerala</td></tr>
<tr><td><b>Chillies (dry) </b></td><td>Tamil Nadu, Andhra Pradesh</td></tr>
<tr><td><b>Coffee </b></td><td>Karnataka, Kerala</td></tr>
<tr><td><b>Coriander </b></td><td>Rajasthan, Andhra Pradesh</td></tr>
<tr><td><b>Cotton </b></td><td>Gujarat, Maharashtra</td></tr>
<tr><td><b>Ginger (dry) </b></td><td>Kerala, Himachal Pradesh</td></tr>
<tr><td><b>Gram </b></td><td>Rajasthan, Uttar Pradesh</td></tr>
<tr><td><b>Ground nut </b></td><td>Gujarat, Tamil Nadu</td></tr>
<tr><td><b>Jowar </b></td><td>Maharashtra, Karnataka</td></tr>
<tr><td><b>Jute </b></td><td>West Bengal, Bihar</td></tr>
<tr><td><b>Maize </b></td><td>Uttar Pradesh, Bihar</td></tr>
<tr><td><b>Millets (small) </b></td><td>Madhya Pradesh, Andhra Pradesh</td></tr>
<tr><td><b>Paddy </b></td><td>West Bengal, Tamil Nadu</td></tr>
<tr><td><b>Pulses (kharif) </b></td><td>Rajasthan, Maharashtra</td></tr>
<tr><td><b>Pulses (rabi) </b></td><td>Odisha, Madhya Pradesh</td></tr>
<tr><td><b>Ragi </b></td><td>Karnataka, Tamil Nadu</td></tr>
<tr><td><b>Rape seed and Mustard </b></td><td>Uttar Pradesh, Rajasthan</td></tr>
<tr><td><b>Rice </b></td><td>West Bengal, Andhra Pradesh, Bihar, Madhya Pradesh</td></tr>
<tr><td><b>Sugarcane </b></td><td>Uttar Pradesh, Maharashtra</td></tr>
<tr><td><b>Tea </b></td><td>Assam, West Bengal</td></tr>
<tr><td><b>Tobacco </b></td><td>Maharashtra, Tamil Nadu</td></tr>
<tr><td><b>Wheat </b></td><td>Uttar Pradesh, Punjab, Haryana</td></tr>
</tbody></table>
<span></span>
<br><br>
          </div>

  <div class="tab-pane" id="fertilizer">
    <br><br>
    <table cellspacing="0" cellpadding="3" border="0" width="90%" align="center" class="table table-bordered table-responsive table-stripped"  style="background-color: rgba(220, 220, 220, .85);">

<tbody><tr><td rowspan="2" colspan="2" class="btbs" bgcolor="#C0C0C0" valign="top"><b>Crop</b></td><td rowspan="2" class="btbs" bgcolor="#C0C0C0" width="15%" valign="top" align="center"><b>Gross cropped area (million ha)</b></td><td rowspan="2" class="btbs" bgcolor="#C0C0C0" width="15%" valign="top" align="center"><b>Share in fertilizer consumption (%)</b></td><td colspan="4" class="btbs" bgcolor="#C0C0C0" align="center"><b>Fertilizer consumption (kg/ha)</b></td></tr>

<tr><td class="bbs" bgcolor="#C0C0C0" width="10%" align="center"><b>N</b></td><td class="bbs" bgcolor="#C0C0C0" width="10%" align="center"><b>P<sub>2</sub>O<sub>5</sub></b></td><td class="bbs" bgcolor="#C0C0C0" width="10%" align="center"><b>K<sub>2</sub>O</b></td><td class="bbs" bgcolor="#C0C0C0" width="10%" align="center"><b>Total</b></td></tr>

<tr><td colspan="2"><b>Cotton</b></td><td align="right"><b>8.5</b></td><td align="right"><b>6</b></td><td align="right"><b>89.5</b></td><td align="right"><b>22.6</b></td><td align="right"><b>4.8</b></td><td align="right"><b>116.8</b></td></tr>

<tr><td width="2%">&nbsp;</td><td>Irrigated</td><td align="right">2.9</td><td align="right">2.7</td><td align="right">115.7</td><td align="right">30.9</td><td align="right">7</td><td align="right">153.5</td></tr>

<tr><td>&nbsp;</td><td>Rainfed</td><td align="right">5.6</td><td align="right">3.3</td><td align="right">75.8</td><td align="right">18.2</td><td align="right">3.6</td><td align="right">97.7</td></tr>

<tr><td colspan="2"><b>Groundnut</b></td><td align="right"><b>6.6</b></td><td align="right"><b>2.9</b></td><td align="right"><b>24.4</b></td><td align="right"><b>39.3</b></td><td align="right"><b>12.9</b></td><td align="right"><b>76.6</b></td></tr>

<tr><td>&nbsp;</td><td>Irrigated</td><td align="right">1.2</td><td align="right">0.8</td><td align="right">35.3</td><td align="right">53.8</td><td align="right">28.9</td><td align="right">118</td></tr>

<tr><td>&nbsp;</td><td>Rainfed</td><td align="right">5.4</td><td align="right">2.1</td><td align="right">21.9</td><td align="right">36</td><td align="right">9.2</td><td align="right">67.2</td></tr>

<tr><td colspan="2"><b>Jute</b></td><td align="right"><b>0.8</b></td><td align="right"><b>0.2</b></td><td align="right"><b>38</b></td><td align="right"><b>11.5</b></td><td align="right"><b>5</b></td><td align="right"><b>54.4</b></td></tr>

<tr><td>&nbsp;</td><td>Irrigated</td><td align="right">0.3</td><td align="right">0.1</td><td align="right">55.9</td><td align="right">22.4</td><td align="right">10.2</td><td align="right">88.6</td></tr>

<tr><td>&nbsp;</td><td>Rainfed</td><td align="right">0.5</td><td align="right">0.1</td><td align="right">28.9</td><td align="right">6</td><td align="right">2.3</td><td align="right">37.1</td></tr>

<tr><td colspan="2"><b>Maize</b></td><td align="right"><b>6.6</b></td><td align="right"><b>2.3</b></td><td align="right"><b>41.7</b></td><td align="right"><b>14.7</b></td><td align="right"><b>3.8</b></td><td align="right"><b>60.2</b></td></tr>

<tr><td>&nbsp;</td><td>Irrigated</td><td align="right">1.5</td><td align="right">0.8</td><td align="right">59.6</td><td align="right">27.7</td><td align="right">4.8</td><td align="right">92.1</td></tr>

<tr><td>&nbsp;</td><td>Rainfed</td><td align="right">5.1</td><td align="right">1.5</td><td align="right">36.6</td><td align="right">11</td><td align="right">3.6</td><td align="right">51.1</td></tr>

<tr><td colspan="2"><b>Paddy</b></td><td align="right"><b>44.7</b></td><td align="right"><b>31.8</b></td><td align="right"><b>81.7</b></td><td align="right"><b>24.3</b></td><td align="right"><b>13.1</b></td><td align="right"><b>119.1</b></td></tr>

<tr><td>&nbsp;</td><td>Irrigated</td><td align="right">24</td><td align="right">22.2</td><td align="right">103.4</td><td align="right">32.8</td><td align="right">18.8</td><td align="right">155</td></tr>

<tr><td>&nbsp;</td><td>Rainfed</td><td align="right">20.7</td><td align="right">9.6</td><td align="right">56.6</td><td align="right">14.5</td><td align="right">6.5</td><td align="right">77.6</td></tr>

<tr><td colspan="2"><b>Pearl millet</b></td><td align="right"><b>9.8</b></td><td align="right"><b>1.7</b></td><td align="right"><b>21.9</b></td><td align="right"><b>5.5</b></td><td align="right"><b>0.8</b></td><td align="right"><b>28.2</b></td></tr>

<tr><td>&nbsp;</td><td>Irrigated</td><td align="right">0.8</td><td align="right">0.4</td><td align="right">62.2</td><td align="right">13.9</td><td align="right">3.4</td><td align="right">79.5</td></tr>

<tr><td>&nbsp;</td><td>Rainfed</td><td align="right">9</td><td align="right">1.3</td><td align="right">18.4</td><td align="right">4.8</td><td align="right">0.6</td><td align="right">23.8</td></tr>

<tr><td colspan="2"><b>Pigeon pea</b></td><td align="right"><b>3.6</b></td><td align="right"><b>0.8</b></td><td align="right"><b>20.9</b></td><td align="right"><b>13.3</b></td><td align="right"><b>2</b></td><td align="right"><b>36.2</b></td></tr>

<tr><td>&nbsp;</td><td>Irrigated</td><td align="right">0.2</td><td align="right">0.1</td><td align="right">36.9</td><td align="right">20.9</td><td align="right">2.2</td><td align="right">60</td></tr>

<tr><td>&nbsp;</td><td>Rainfed</td><td align="right">3.5</td><td align="right">0.7</td><td align="right">19.6</td><td align="right">12.6</td><td align="right">2</td><td align="right">34.2</td></tr>

<tr><td colspan="2"><b>Rapeseed &amp; mustard</b></td><td align="right"><b>6</b></td><td align="right"><b>3.4</b></td><td align="right"><b>69.1</b></td><td align="right"><b>25</b></td><td align="right"><b>2.9</b></td><td align="right"><b>97</b></td></tr>

<tr><td>&nbsp;</td><td>Irrigated</td><td align="right">3.8</td><td align="right">2.6</td><td align="right">81.7</td><td align="right">30.4</td><td align="right">4.3</td><td align="right">116.5</td></tr>

<tr><td>&nbsp;</td><td>Rainfed</td><td align="right">2.2</td><td align="right">0.8</td><td align="right">45.9</td><td align="right">15</td><td align="right">0.4</td><td align="right">61.3</td></tr>

<tr><td colspan="2"><b>Sorghum</b></td><td align="right"><b>9.9</b></td><td align="right"><b>2.9</b></td><td align="right"><b>29.2</b></td><td align="right"><b>14.2</b></td><td align="right"><b>4.1</b></td><td align="right"><b>47.5</b></td></tr>

<tr><td>&nbsp;</td><td>Irrigated</td><td align="right">0.8</td><td align="right">0.5</td><td align="right">58.5</td><td align="right">29.1</td><td align="right">10.7</td><td align="right">98.3</td></tr>

<tr><td>&nbsp;</td><td>Rainfed</td><td align="right">9.1</td><td align="right">2.4</td><td align="right">26.9</td><td align="right">13</td><td align="right">3.6</td><td align="right">43.6</td></tr>

<tr><td colspan="2"><b>Sugar cane</b></td><td align="right"><b>4.3</b></td><td align="right"><b>5.4</b></td><td align="right"><b>124.8</b></td><td align="right"><b>44</b></td><td align="right"><b>38.3</b></td><td align="right"><b>207.1</b></td></tr>

<tr><td>&nbsp;</td><td>Irrigated</td><td align="right">4.2</td><td align="right">5.3</td><td align="right">126.4</td><td align="right">45</td><td align="right">40.6</td><td align="right">212</td></tr>

<tr><td>&nbsp;</td><td>Rainfed</td><td align="right">0.1</td><td align="right">0.1</td><td align="right">106</td><td align="right">32</td><td align="right">12.4</td><td align="right">150.4</td></tr>

<tr><td colspan="2"><b>Wheat</b></td><td align="right"><b>25.7</b></td><td align="right"><b>21</b></td><td align="right"><b>99.6</b></td><td align="right"><b>30.2</b></td><td align="right"><b>6.9</b></td><td align="right"><b>136.7</b></td></tr>

<tr><td>&nbsp;</td><td>Irrigated</td><td align="right">22.8</td><td align="right">19.7</td><td align="right">105.6</td><td align="right">32.1</td><td align="right">7.3</td><td align="right">144.9</td></tr>

<tr><td>&nbsp;</td><td>Rainfed</td><td align="right">2.9</td><td align="right">1.3</td><td align="right">55.7</td><td align="right">15.9</td><td align="right">4.3</td><td align="right">75.9</td></tr>

<tr><td colspan="2"><b>Other crops</b></td><td align="right"><b>60.4</b></td><td align="right"><b>21.6</b></td><td align="right"><b>34.5</b></td><td align="right"><b>18.5</b></td><td align="right"><b>7.1</b></td><td align="right"><b>60.1</b></td></tr>

<tr><td>&nbsp;</td><td>Irrigated</td><td align="right">12.6</td><td align="right">13.3</td><td align="right">113.5</td><td align="right">46.8</td><td align="right">16.5</td><td align="right">176.7</td></tr>

<tr><td>&nbsp;</td><td>Rainfed</td><td align="right">47.8</td><td align="right">8.3</td><td align="right">13.6</td><td align="right">11</td><td align="right">4.7</td><td align="right">29.3</td></tr>

<tr><td colspan="2"><b>All crops</b></td><td align="right"><b>187</b></td><td align="right"><b>100</b></td><td align="right"><b>59.2</b></td><td align="right"><b>22.1</b></td><td align="right"><b>8.5</b></td><td align="right"><b>89.8</b></td></tr>

<tr><td>&nbsp;</td><td>Irrigated</td><td align="right">75.1</td><td align="right">68.5</td><td align="right">103.2</td><td align="right">35.3</td><td align="right">14.5</td><td align="right">153.1</td></tr>

<tr><td class="bbs">&nbsp;</td><td class="bbs">Rainfed</td><td class="bbs" align="right">111.9</td><td class="bbs" align="right">31.5</td><td class="bbs" align="right">29.7</td><td class="bbs" align="right">13.1</td><td class="bbs" align="right">4.5</td><td class="bbs" align="right">47.3</td></tr>

</tbody></table>
  </div>
          <div class="tab-pane" id="season">
            <br><br>
            <table class="table able-bordered table-responsive table-stripped" style="background-color: rgba(220, 220, 220, .85);">
              <thead>
                <tr bgcolor="#C0C0C0">
                  <th>Type of crop</th>
                  <th>Sown in</th>
                  <th>Crops</th>
                 
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>Kharif crops</td>
                  <td>June and July</td>
                  <td>rice, jowar, maize, cotton, ragi, bajra, sugarcane and jute</td>
                  
                </tr>
                <tr>
                  <td>Rabi crops</td>
                  <td>October and December</td>
                  <td>wheat, peas, pulses, mustard and rapeseed.</td>
                 
                </tr>
                <tr>
                  <td>Zaid crops</td>
                  <td>Summer</td>
                  <td>rice, maize, sunflower, vegetables and groundnut</td>
                  
                </tr>
              </tbody>
            </table>
          </div>

          <div id="soil" class="tab-pane">
            <br>
            <br>
            <div style="text-align: right; color: gray; font-size: 75%;">Click <a  " onclick="window.open('https://www.mapsofindia.com/maps/india/india-map-of-soils.jpg', 'India soil map','menubar=0,fullscreen=1,location=0') ">here</a> for india soil map</div>
            <table class="table able-bordered table-responsive table-stripped" style="background-color: rgba(220, 220, 220, .85);">
              <thead>
                <tr bgcolor="#C0C0C0">
                  <th>Soil</th>
                  <th>Crops</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>Alluvial Soil</td>
                  <td>Rice, wheat, sugarcane, cotton and jute </td>
                  
                </tr>
                <tr>
                  <td>Black Soil</td>
                  <td>rice, wheat, sugarcane and cotton</td>
                  
                </tr>
                <tr>
                  <td>Desert Soil</td>
                  <td>barley and millet </td>
                  
                </tr>
                <tr>
                  <td>Laterite Soil</td>
                  <td>cashew, rubber, coconut, tea and coffee</td>
                  
                </tr>
                <tr>
                  <td>Mountain Soil</td>
                  <td>tea, coffee, spices and many types of tropical fruits</td>
                  
                </tr>
                <tr>
                  <td>Red and Yellow Soil</td>
                  <td>rice, wheat, sugarcane, millet, groundnut, ragi and potato</td>
                  
                </tr>
              </tbody>
            </table>
          </div>
<div id="price" class="tab-pane">
  <div>
    <br><br>
    Showing results for location <b style="color: black;"><?php if(!isset($_GET['loc'])) echo "Bangalore"; else echo $_GET['loc'];?></b><select style="float: right;" onchange="location.href='frontpage.php?loc='+this.value+'#price';">
      <option>City</option>
      <?php
      include('auth.php');
      $q9 = "SELECT DISTINCT city FROM crop;"  ;
      $r = $con->query($q9);
      while($row = $r->fetch_assoc()) echo "<option value='$row[city]'>$row[city]</option>";
      ?>
    </select>
    <table class="table table-bordered table-responsive table-stripped" style="background-color: rgba(220, 220, 220, .85);">
      <thead style="background-color: #C0C0C0;">
        <TR>
          <TH>Name</TH><TH>price</TH>
        </TR>
      </thead>
          <?php
          if(!isset($_GET['loc']))
        $q = "SELECT name, price FROM crop where city='bangalore';";
          else
        $q = "SELECT name, price FROM crop where city='".$_GET['loc']."';";

        include('auth.php');
        $r = $con->query($q);
        while($row = $r->fetch_assoc())
        {
          echo "<tr><td>$row[name]</td><td>$row[price]</td></tr>";
        }
        ?> 
      
        
      
    </table>
  </div>
</div>
    
         <div id="tech" class="tab-pane">
           <br>
           <br>
           <div class="container" style="background-image: url('bg.gif'); border-radius: 2px 2px 2px 2px; box-shadow: 0px 0px 5px #888888; color: white;">
             <br><br>

             <?php
                include('auth.php');
                $q = "select name, content, imgl from tech order by dat desc;" ;
                if($r = $con->query($q)){
                  while ($t = $r->fetch_assoc()) {
                    # code...
                    $t['imgl']=str_replace(" ","_",$t['imgl']);
                    echo "<div class=\"row\">
             <div class=\"col-md-9\"><h3>$t[name]</h3>$t[content]
              </div>
              <div class=\"col-md-3\">
              <img  src=\"$t[imgl]\" style=\" margin: auto;  height: 200px; width:250px;\">
            </div>
            </div><br>";
                  }
                }
             ?>
            <div class="row">
             <div class="col-md-9"><h3>Harrow</h3>The harrow was necessary to smoothen the soil in areas where the soil remained rough. It consists of a wooden or metal framework bearing metal disks, teeth, or sharp projecting points, called tines, which is dragged over plowed land to crush the clods of earth and level the soil. Harrows are also used to uproot weeds, aerate the soil, and cover seeds.
              </div>
              <div class="col-md-3">
              <img  src="https://www.faizantraders.com/wp-content/uploads/2015/01/Disc-Harrow-e1461070966407.jpg" alt="Harrow" style=" margin: auto;  height: 200px; width:250px;">
            </div>
            </div>

            <br><br>

            <div class="row">
             <div class="col-md-9"><h3>Seed Driller</h3>Seed drill was an innovation that allowed seeds to be easily planted deep into the earth instead of on top where the majority were washed away or otherwise lost. The machine was pulled by horses and consisted of rotating drills or runners that planted seeds at a set depth.
              </div>
              <div class="col-md-3">
              <img  src="https://upload.wikimedia.org/wikipedia/commons/4/4c/Sowing_machine_Nordsten.jpg" alt="Harrow" style="margin: auto; height: 200px; width:250px;">
            </div>
            </div>

            <br><br>
            
             <div class="row">
             <div class="col-md-9"><h3>Threshing Machines</h3>Prior to the threshing machines farmers used an implement called 'flail' to simply beat the grain with sticks or ropes to knock the seeds from the stalks. But this was a back-breaking work and was of low productivity. Threshing machines were designed for rapidly removing the husks from grain.<br>

With improvements in design and efficiency, threshing machines became progressively more common and the hand flail was gradually consigned to history. The machines could be driven by wind or water power, or by horses, but the steam powered thresher became the most familiar sight. They were eventually replaced in the middle decades of the twentieth century by the combine harvester which both harvests and threshes the crop in the field in a single operation.
 
              </div>
              <div class="col-md-3">
              <img  src="https://i.ytimg.com/vi/NHAgawl5uec/maxresdefault.jpg" alt="Harrow" style=" margin: auto; height: 200px; width:250px;">
            </div>
            </div>

            <br><br>

            <div class="row">
             <div class="col-md-9"><h3>BIOSAT</h3>BIOSAT (Biochar based organic Soil Amendment Technology), a soil additive, is made of biochar mixed with different organic nutrients. The product preserves soil fertility, traps carbon emissions, maintains the topsoil strength and increases crop production, thus reducing dependency on chemical fertilizers.
              </div>
              <div class="col-md-3">
              <img  src="http://13462-presscdn-0-60.pagely.netdna-cdn.com/wp-content/uploads/2015/09/484090_410144729062067_1515037519_n-650x507.jpg" alt="Harrow" style=" margin: auto; height: 200px; width:250px;">
            </div>
            </div>

            <br><br>

            <div class="row">
             <div class="col-md-9"><h3>Air blast sprayers</h3>Developed for fruits and vegetables in general, and grapes and pomegranates in particular, the sprayers, used to add hormones that help the growth of crops, reduce the expenditure on manual labour and are less time-consuming.
              </div>
              <div class="col-md-3">
              <img  src="http://13462-presscdn-0-60.pagely.netdna-cdn.com/wp-content/uploads/2015/09/10835313_650540761745005_1258791865372273648_o-650x433.jpg" alt="Harrow" style=" margin: auto; height: 200px; width:250px;">
            </div>
            </div>

            <br><br>

            <div class="row">
             <div class="col-md-9"><h3>Kisan Raja</h3> GSM-based Mobile Motor Controller which is controlled by the farmers even from their homes through mobile phones or landlines. Earlier farmers used to get up at odd hours to switch off the motors. This device resolved this problem.  Its key features are Convenience, Protection and Comprehension.
              </div>
              <div class="col-md-3">
              <img  src="http://www.iamwire.com/wp-content/uploads/2017/01/Kisan-Raja-469x1024.png" alt="Harrow" style=" margin: auto; height: 200px; width:250px;">
            </div>
            </div>

            <br>


              <div class="row">
             <div class="col-md-9"><h3>RML Farmer, RML Trader and Redge</h3> RML, an android app makes sure that farmers are selling their produce at an appropriate rate. It helps in linking farmers, traders and agribusiness companies. It has benefited over 2 million people from 13 Indian states.
              </div>
              <div class="col-md-3">
              <img  src="http://www.iamwire.com/wp-content/uploads/2017/01/RML.png" alt="Harrow" style=" margin: auto; height: 200px; width:250px;">
            </div>
            </div>

            <br>  

            <br><br>
           </div>
         </div>
         <div id="news" class="tab-pane"><br><br>
          <!--  <div id="carouselvideo" class="carousel slide" data-ride="carousel">
  <div class="carousel-inner" role="listbox">
    <div class="item active" >
      <iframe width="560" height="315" src="https://www.youtube.com/embed/ZpPtAMD-t84" frameborder="0" allowfullscreen></iframe>
    </div>
    <div class="item" >
      <iframe width="560" height="315" src="https://www.youtube.com/embed/ZpPtAMD-t84" frameborder="0" allowfullscreen></iframe>
    </div>
    <div class="item" >
      <iframe width="560" height="315" src="https://www.youtube.com/embed/ZpPtAMD-t84" frameborder="0" allowfullscreen></iframe>
    </div>
    <ol class="carousel-indicators">
    <li target="#carouselvideo" data-slide-to="0" class="active"></li>
    <li  target="#carouselvideo" data-slide-to="1"></li>
    <li  target="#carouselvideo" data-slide-to="2"></li>
  </ol>
  </div>
  
</div> -->
<center>
  <?php
        include('auth.php');
        $q = "SELECT link FROM vids order by dat desc limit 5;";
        $r = $con->query($q);
        $v = array();
       
        while($row = $r->fetch_assoc())
        {
          array_push($v, $row['link']);
          

        }
    
        ?> 
  <div id="carouselvideo" class="carousel slide" data-ride="carousel">
 

  <div class="carousel-inner" role="listbox">
    <div class="item active">
<!-- <iframe width="560" height="315" src="https://www.youtube.com/embed/9J1isnYbguA" frameborder="0" gesture="media" allowfullscreen></iframe>   --> <?php echo $v[0];?> </div>
    <div class="item">
<!-- <iframe width="560" height="315" src="https://www.youtube.com/embed/uCPEYhSGu-E" frameborder="0" gesture="media" allowfullscreen></iframe>  --> <?php echo $v[1];?>  </div>
    <div class="item">
     <!-- <iframe width="560" height="315" src="https://www.youtube.com/embed/ZpPtAMD-t84" frameborder="0" allowfullscreen></iframe> --><?php echo $v[2];?>
    </div>
    <div class="item">
<!-- <iframe width="560" height="315" src="https://www.youtube.com/embed/1lgc2NU9vuc" frameborder="0" gesture="media" allowfullscreen></iframe>  --> <?php echo $v[3];?>    
    </div>
    <div class="item">
<!-- <iframe width="560" height="315" src="https://www.youtube.com/embed/PXLL6nwiUz8" frameborder="0" gesture="media" allowfullscreen></iframe>   -->    <?php echo $v[4];?>
    </div>
  </div>
     <ol class="carousel-indicators">
    <li data-target="#carouselvideo" data-slide-to="0" class="active"></li>
    <li data-target="#carouselvideo" data-slide-to="1"></li>
    <li data-target="#carouselvideo" data-slide-to="2"></li>
    <li data-target="#carouselvideo" data-slide-to="3"></li>
    <li data-target="#carouselvideo" data-slide-to="4"></li>
  </ol>
</div>
</center>
         </div>
      </div>
      <!-- </div> -->
      </div>
      <br>
      <br>
      <div class="container"  style=" ">
      <br>
      <br>
      
      
      <script type="text/javascript">
        $("#exp li").after("<br/>");
         $("#begb").click(function(){
          $("#exp").css({"display":"none"});
         $("#beg").toggle();
         $("#beg").focus();
         window.scrollTo(00,280);
         });
         $("#expb").click(function(){
          $("#beg").css({"display":"none"});
         $("#exp").toggle();
         $("#exp").focus();
         window.scrollTo(00,280);
         });
         function locr(r){

         }
      </script>
   </body>
</html>